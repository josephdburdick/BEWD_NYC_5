"steven".send :upcase
"steven".upcase
